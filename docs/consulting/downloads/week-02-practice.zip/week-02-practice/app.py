"""Classroom reference app. Run from an extracted week-specific practice pack."""
from pathlib import Path
from hashlib import sha256
import pandas as pd
import plotly.express as px
import streamlit as st
from analysis_core import validate, subset, summary, bands, compare_means, category_test

WEEK = 2
ROOT = Path(__file__).resolve().parent
st.set_page_config(page_title=f'{WEEK}주차 고객 이탈 실습',layout='wide')
st.title(f'{WEEK}주차 고객 이탈 현황 탐색')
st.caption('학습용 가상 데이터. 고객 1명당 1행 / 금액 CU / 기준 시점 이후 공통 관찰기간의 이탈 여부를 가정합니다.')
choice=st.sidebar.selectbox('실습 데이터',['100행 가상 자료','8행 검증 자료'])
file_name='sample_churn.csv' if choice=='100행 가상 자료' else 'validation_8rows.csv'
uploaded=None
if WEEK<4:
    uploaded=st.sidebar.file_uploader('로컬 실습용 CSV 업로드',type=['csv'])
else:
    st.sidebar.caption('4주차 공개 실습 모드: 제공된 가상 자료만 선택합니다.')
try:
    raw=pd.read_csv(uploaded if uploaded is not None else ROOT/'data'/file_name)
    clean,quality,reasons=validate(raw)
except (ValueError, OSError, pd.errors.ParserError) as exc:
    st.error(str(exc));st.stop()
st.subheader('데이터 품질 점검')
st.write(quality)
with st.expander('오류 유형별 건수와 원자료'):
    st.dataframe(reasons.rename('건수'));st.dataframe(raw)
if clean.empty:
    st.warning('분석 가능한 고객이 없습니다. 원자료와 제외 조건을 확인하세요.');st.stop()
selected=clean
if WEEK>=3:
    def reset():
        st.session_state['low']=0
        st.session_state['high']=int(clean['tenure_months'].max())
    data_signature=choice if uploaded is None else sha256(uploaded.getvalue()).hexdigest()
    if st.session_state.get('_data_name') != data_signature:
        st.session_state['low']=0;st.session_state['high']=int(clean['tenure_months'].max())
        st.session_state['_data_name']=data_signature
    st.sidebar.button('전체 조건',on_click=reset)
    low=st.sidebar.number_input('가입기간 최솟값',min_value=0,value=None,step=1,key='low')
    high=st.sidebar.number_input('가입기간 최댓값',min_value=0,value=None,step=1,key='high')
    if low is None or high is None:
        st.info('가입기간 최솟값과 최댓값을 입력하세요.');st.stop()
    try: selected=subset(clean,low,high)
    except ValueError as exc: st.error(str(exc));st.stop()
    condition=f'가입기간 {low}–{high}개월'
else:
    condition='전체 가입기간'
st.write(f'현재 자료: {"업로드 CSV" if uploaded is not None else choice} / {condition} / 선택 {len(selected)}명, 정제 후 전체 {len(clean)}명')
s=summary(selected)
a,b,c=st.columns(3)
a.metric('분석 고객 수',f'{s["n"]}명')
b.metric('이탈 비율','계산 불가' if s['rate'] is None else f'{s["rate"]:.1f}%')
b.caption(f'{s["churn"]}명 / {s["n"]}명')
c.metric('평균 월 청구 금액','계산 불가' if s['mean'] is None else f'{s["mean"]:.1f} CU')
if selected.empty:
    st.info('선택한 조건에 해당하는 고객이 없습니다. 조건을 넓혀보세요.');st.stop()
variable=st.selectbox('비교할 연속형 변수',['monthly_charges','tenure_months','age'])
unit={'monthly_charges':'CU','tenure_months':'개월','age':'세'}[variable]
plot_df=selected.copy();plot_df['집단']=plot_df['churn'].map({0:'유지',1:'이탈'})
st.subheader('분포와 집단 비교')
l,r=st.columns(2)
l.plotly_chart(px.histogram(plot_df,x=variable,nbins=12,labels={variable:f'{variable} ({unit})'},title='선택 고객의 분포'),width='stretch')
r.plotly_chart(px.box(plot_df,x='집단',y=variable,points='all',labels={variable:f'{variable} ({unit})'},title='유지·이탈 집단의 분포'),width='stretch')
st.dataframe(selected.groupby('churn')[variable].agg(['count','mean','std']).rename(index={0:'유지',1:'이탈'}))
if WEEK>=3:
    st.subheader('가입기간 구간별 요약');st.dataframe(bands(selected))
st.subheader('두 집단 평균 비교: 학습용 탐색')
method=st.selectbox('검정 방식',['Welch (기본)','Levene 결과에 따른 분기 (학습 예시)'])
test=compare_means(selected,variable,'welch' if method.startswith('Welch') else 'levene_demo')
if 'error' in test:
    st.info(test['error'])
else:
    st.write(f'{test["name"]} 양측 독립표본 t-검정 / 이탈 n={test["n_churn"]}, 유지 n={test["n_keep"]}')
    levene_text='계산 불가' if test['levene_p'] is None else f'{test["levene_p"]:.4f}'
    st.write(f't={test["t"]:.4f}, p={test["p"]:.4f}, Levene p={levene_text}')
    st.write(f'평균 차이(이탈−유지)={test["difference"]:.4f} {unit}')
    st.caption('Levene p≥0.05는 등분산을 입증하지 않습니다. 독립성·분포·표본 수는 별도로 판단합니다. 가상 자료의 결과를 실제 원인이나 사업 효과로 해석하지 않습니다.')
if 'contract_type' in selected:
    with st.expander('선택 심화: 계약유형과 이탈의 카이제곱 검정'):
        ct=category_test(selected,'contract_type')
        if 'error' in ct: st.info(ct['error'])
        else:
            st.dataframe(ct['observed']);st.write(f'χ²={ct["chi2"]:.4f}, p={ct["p"]:.4f}, 자유도={ct["dof"]}, 최소 기대빈도={ct["min_expected"]:.2f}')
            st.caption('연속성 보정을 적용하지 않은 학습 예제입니다. 독립 관측과 기대빈도 조건을 확인하세요.')
            if ct['min_expected']<5: st.warning('기대빈도가 5 미만인 셀이 있습니다. 근사 검정의 적절성을 추가 검토하세요.')
st.subheader('사실과 다음 확인')
st.write(f'학습용 가상 자료에서 {condition} 고객 {s["n"]}명 중 {s["churn"]}명이 이탈해 비율은 {s["rate"]:.1f}%입니다.')
st.write('이 자료만으로 원인을 확정할 수 없습니다. 실제 기업에서는 관찰기간과 상품·계약·이용경험 자료를 추가로 확인해야 합니다.')
