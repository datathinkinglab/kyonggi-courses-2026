# 통계컨설팅 3주차 실습 시작 파일

## 시작
1. ZIP 전체를 압축 해제합니다. ZIP 안에서 앱을 직접 실행하지 않습니다.
2. Python 3.12를 준비하고 이 폴더에서 터미널을 엽니다.
3. 가상 환경을 생성합니다: `python -m venv .venv`
4. Windows: `.venv\Scripts\python.exe -m pip install -r requirements.txt`
5. Windows: `.venv\Scripts\python.exe -m streamlit run app.py`
6. macOS/Linux는 위 실행 경로를 `.venv/bin/python`으로 바꿉니다.
7. 터미널에 나타난 Local URL을 브라우저에서 엽니다. 종료는 Ctrl+C입니다.

일반 Python 환경을 직접 사용할 때는 `python -m pip install -r requirements.txt`,
`python -m streamlit run app.py`로 설치·실행합니다.
시스템에 python 명령이 없다면 Windows에서는 py 또는 설치한 Python 경로를 사용합니다.
실행 환경은 Python 3.12에서 검증했습니다. 패키지 버전은 requirements.txt에 있습니다.

## 자료와 기대 결과
- 초기 100행: 고객 100명, 이탈 21명, 이탈 비율 21.0%, 평균 71.6 CU.
- 8행 선택: 8명, 3명 이탈, 37.5%, 평균 52.5 CU.
- 2·3주차는 로컬 CSV 업로드를 지원합니다.
- 3·4주차는 가입기간 필터를 지원합니다. 0–11개월: 4명·50.0%·50.0 CU.
- 6–10개월: 고객 0명, 비율·평균 계산 불가. 전체 조건 버튼으로 복귀합니다.

## 파일 역할
- app.py: 화면과 선택 기능. analysis_core.py: 정제·계산·검정.
- data: 두 CSV. DATA_DICTIONARY.md: 변수·단위·정답 설명.
- PRD.md: 사용자·질문·규칙. requirements.txt: 검증한 패키지 버전.

## 수업 활동
1. 참고 앱을 실행해 예상 수치를 확인합니다.
2. 자신의 PRD로 기능을 하나씩 AI에 요청해 구현하거나 참고 앱을 수정합니다.
3. 작은 검증 자료와 예외 조건으로 계산을 확인합니다.
4. 주요 요청문, 직접 수정한 부분, 검증표와 역할을 기록합니다.
파일을 그대로 제출하는 것만으로 분석·검증 활동이 완료되지는 않습니다.

## 4주차 배포
이 폴더 전체를 GitHub 저장소에 올립니다. app.py와 requirements.txt는 최상위,
두 CSV는 data 폴더에 둡니다. Streamlit Community Cloud에 저장소·브랜치·app.py를 지정하고
호환되는 Python 버전을 선택합니다. 다른 조가 8행 수치와 필터를 확인해야 배포 완료입니다.

## 검정 해석
두 집단 평균의 기본 비교는 Welch 양측 독립표본 t-검정입니다.
Levene 결과에 따른 Student/Welch 분기는 학습용 선택 기능입니다.
독립성·분포·표본 수는 별도로 검토해야 합니다. p≥0.05로 귀무가설을 입증하지 않습니다.
계약유형 카이제곱 예제는 연속성 보정을 사용하지 않습니다. 작은 기대빈도는 별도 검토합니다.
가상 자료에서 보이는 관계를 실제 원인이나 예측 성능으로 해석하지 않습니다.
